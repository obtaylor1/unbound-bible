/* Ethiopian Orthodox Bible — App Logic */

(function() {
  'use strict';

  let bookIndex = null;
  let currentBook = null;
  let currentChapter = 1;
  let bookCache = {};
  let searchTimeout = null;

  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => document.querySelectorAll(sel);

  // --- Theme Toggle ---
  (function initTheme() {
    const toggle = $('[data-theme-toggle]');
    const root = document.documentElement;
    let theme = matchMedia('(prefers-color-scheme:dark)').matches ? 'dark' : 'light';
    root.setAttribute('data-theme', theme);
    updateThemeIcon(theme);
    toggle.addEventListener('click', () => {
      theme = theme === 'dark' ? 'light' : 'dark';
      root.setAttribute('data-theme', theme);
      updateThemeIcon(theme);
    });
    function updateThemeIcon(t) {
      toggle.innerHTML = t === 'dark'
        ? '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>'
        : '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>';
      toggle.setAttribute('aria-label', 'Switch to ' + (t === 'dark' ? 'light' : 'dark') + ' mode');
    }
  })();

  // --- Load Index ---
  fetch('data/index.json')
    .then(r => r.json())
    .then(data => {
      bookIndex = data;
      renderBookNav(data.books, data.categories);
      updateStats(data.books);
    })
    .catch(err => {
      $('#reading-area').innerHTML = '<p class="welcome-text">Error loading Bible index. Please refresh.</p>';
    });

  function updateStats(books) {
    const available = books.filter(b => !b.unavailable);
    let totalChapters = 0;
    let totalVerses = 0;
    available.forEach(b => {
      totalChapters += b.chapters || 0;
      // Load verse count lazily — for now show chapters
    });
    // Count verses from loaded data
    Promise.all(available.slice(0, 5).map(b => 
      fetch(b.file).then(r => r.json()).then(d => {
        return d.reduce((acc, ch) => acc + (ch.v ? ch.v.length : 0), 0);
      }).catch(() => 0)
    )).then(() => {
      $('#stat-books').textContent = available.length;
      $('#stat-chapters').textContent = totalChapters.toLocaleString();
      $('#stat-verses').textContent = '44,000+';
    });
  }

  // --- Render Book Navigation ---
  function renderBookNav(books, categories) {
    const nav = $('#book-nav');
    nav.innerHTML = '';

    // Group by category
    const grouped = {};
    books.forEach(b => {
      if (!grouped[b.cat]) grouped[b.cat] = [];
      grouped[b.cat].push(b);
    });

    // Category order
    const catOrder = ['law', 'history', 'wisdom', 'prophets', 'deuterocanonical', 'ethiopian', 'gospels', 'acts', 'pauline', 'general', 'nt_canon'];

    catOrder.forEach(cat => {
      if (!grouped[cat]) return;
      const section = document.createElement('div');
      section.className = 'book-category';

      const label = document.createElement('div');
      label.className = 'cat-label';
      label.textContent = categories[cat] || cat;
      section.appendChild(label);

      grouped[cat].forEach(book => {
        const item = document.createElement('div');
        item.className = 'book-item';
        if (book.unavailable) item.classList.add('unavailable');

        const name = document.createElement('span');
        name.textContent = book.name;
        item.appendChild(name);

        if (book.src === 'kjv_apocrypha') {
          const badge = document.createElement('span');
          badge.className = 'badge badge-kjv';
          badge.textContent = 'KJV';
          badge.title = 'KJV 1611 fallback — no non-KJV public domain version found';
          item.appendChild(badge);
        } else if (book.src === 'meqabyan') {
          const badge = document.createElement('span');
          badge.className = 'badge badge-meq';
          badge.textContent = 'EC';
          badge.title = 'Ethiopian Canon — Meqabyan (not Greek Maccabees)';
          item.appendChild(badge);
        } else if (book.src === 'extra') {
          const badge = document.createElement('span');
          badge.className = 'badge';
          badge.textContent = 'EC';
          badge.title = 'Ethiopian Canon';
          item.appendChild(badge);
        } else if (book.src === 'web_apocrypha' || book.src === 'peshitta' || book.src === 'wmb') {
          // Non-KJV sources — no badge needed, source shown in reader
        }

        if (!book.unavailable) {
          item.addEventListener('click', () => selectBook(book));
        } else {
          item.title = book.note || 'Not available in English translation';
        }

        section.appendChild(item);
      });

      nav.appendChild(section);
    });
  }

  // --- Select Book ---
  function selectBook(book) {
    currentBook = book;
    currentChapter = 1;

    // Update active state
    $$('.book-item').forEach(el => el.classList.remove('active'));
    event.currentTarget.classList.add('active');

    // Update header
    $('#current-book').textContent = book.alt_name ? `${book.name} (${book.alt_name})` : book.name;

    // Show translation source
    const transEl = $('#current-trans') || (() => {
      const el = document.createElement('div');
      el.id = 'current-trans';
      el.className = 'trans-label';
      $('.reader-title').appendChild(el);
      return el;
    })();
    transEl.textContent = book.trans || '';

    // Populate chapter select
    const select = $('#chapter-select');
    select.innerHTML = '';
    for (let i = 1; i <= book.chapters; i++) {
      const opt = document.createElement('option');
      opt.value = i;
      opt.textContent = i;
      select.appendChild(opt);
    }
    select.value = '1';

    loadChapter(book, 1);

    // Close sidebar on mobile
    if (window.innerWidth <= 768) {
      $('#sidebar').classList.remove('open');
      $('#backdrop').classList.remove('show');
    }
  }

  // --- Load Chapter ---
  async function loadChapter(book, chapterNum) {
    currentChapter = chapterNum;
    $('#current-chapter').textContent = `Chapter ${chapterNum}`;
    $('#chapter-select').value = chapterNum;

    const area = $('#reading-area');
    area.innerHTML = '<div style="text-align:center;padding:3rem;color:var(--color-text-muted);">Loading...</div>';

    try {
      if (!bookCache[book.id]) {
        const res = await fetch(book.file);
        bookCache[book.id] = await res.json();
      }

      const chapters = bookCache[book.id];
      const chapter = chapters.find(c => c.c === chapterNum);

      if (!chapter || !chapter.v || chapter.v.length === 0) {
        area.innerHTML = `<div class="welcome"><p class="welcome-text">No text available for this chapter.</p></div>`;
        return;
      }

      let html = '<div class="chapter-text">';
      chapter.v.forEach(v => {
        html += `<div class="verse" data-v="${v.n}">`;
        html += `<span class="verse-num" title="Copy verse">${v.n}</span>`;
        html += `<span class="verse-text">${escapeHtml(v.t)}</span>`;
        html += `</div>`;
      });
      html += '</div>';
      area.innerHTML = html;

      // Scroll to top
      area.parentElement.scrollTop = 0;
      window.scrollTo(0, 0);

      // Verse click to copy
      $$('.verse-num').forEach(el => {
        el.addEventListener('click', function() {
          const verse = this.parentElement;
          const text = verse.querySelector('.verse-text').textContent;
          const ref = `${book.name} ${chapterNum}:${this.textContent}`;
          copyToClipboard(`${ref} — ${text}`);
          verse.classList.add('highlighted');
          setTimeout(() => verse.classList.remove('highlighted'), 1500);
        });
      });

    } catch (err) {
      area.innerHTML = `<div class="welcome"><p class="welcome-text">Error loading chapter: ${err.message}</p></div>`;
    }
  }

  // --- Chapter Navigation ---
  $('#chapter-select').addEventListener('change', function() {
    if (currentBook) loadChapter(currentBook, parseInt(this.value));
  });

  $('#prev-chapter').addEventListener('click', () => {
    if (!currentBook || currentChapter <= 1) return;
    loadChapter(currentBook, currentChapter - 1);
  });

  $('#next-chapter').addEventListener('click', () => {
    if (!currentBook || currentChapter >= currentBook.chapters) return;
    loadChapter(currentBook, currentChapter + 1);
  });

  // Keyboard navigation
  document.addEventListener('keydown', (e) => {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT') return;
    if (e.key === 'ArrowLeft') $('#prev-chapter').click();
    if (e.key === 'ArrowRight') $('#next-chapter').click();
  });

  // --- Search ---
  $('#search').addEventListener('input', function() {
    clearTimeout(searchTimeout);
    const query = this.value.trim();
    const results = $('#search-results');

    if (query.length < 3) {
      results.classList.add('hidden');
      results.innerHTML = '';
      return;
    }

    searchTimeout = setTimeout(() => searchBible(query), 300);
  });

  async function searchBible(query) {
    const results = $('#search-results');
    results.innerHTML = '<div style="padding:0.5rem;color:var(--color-text-muted);font-size:0.75rem;">Searching...</div>';
    results.classList.remove('hidden');

    const lowerQuery = query.toLowerCase();
    const matches = [];
    const books = bookIndex.books.filter(b => !b.unavailable);

    // Search through all books
    for (const book of books) {
      if (!bookCache[book.id]) {
        try {
          const res = await fetch(book.file);
          bookCache[book.id] = await res.json();
        } catch { continue; }
      }

      const chapters = bookCache[book.id];
      for (const ch of chapters) {
        if (!ch.v) continue;
        for (const v of ch.v) {
          if (v.t.toLowerCase().includes(lowerQuery)) {
            matches.push({
              book: book.name,
              chapter: ch.c,
              verse: v.n,
              text: v.t
            });
            if (matches.length >= 50) break;
          }
        }
        if (matches.length >= 50) break;
      }
      if (matches.length >= 50) break;
    }

    if (matches.length === 0) {
      results.innerHTML = '<div style="padding:0.5rem;color:var(--color-text-muted);font-size:0.75rem;">No results found.</div>';
      return;
    }

    results.innerHTML = '';
    matches.forEach(m => {
      const el = document.createElement('div');
      el.className = 'search-result';
      el.innerHTML = `<span class="ref">${m.book} ${m.chapter}:${m.verse}</span><span class="text">${truncate(m.text, 80)}</span>`;
      el.addEventListener('click', () => {
        $('#search-results').classList.add('hidden');
        $('#search').value = '';
        // Find and select the book
        const bookMeta = bookIndex.books.find(b => b.name === m.book);
        if (bookMeta) {
          currentBook = bookMeta;
          $$('.book-item').forEach(el => el.classList.remove('active'));
          loadChapter(bookMeta, m.chapter);
          $('#current-book').textContent = bookMeta.alt_name ? `${bookMeta.name} (${bookMeta.alt_name})` : bookMeta.name;
          // Show translation source
          const transEl = $('#current-trans');
          if (transEl) transEl.textContent = bookMeta.trans || '';
          // Update chapter select
          const select = $('#chapter-select');
          select.innerHTML = '';
          for (let i = 1; i <= bookMeta.chapters; i++) {
            const opt = document.createElement('option');
            opt.value = i;
            opt.textContent = i;
            select.appendChild(opt);
          }
          select.value = m.chapter;
        }
      });
      results.appendChild(el);
    });

    if (matches.length >= 50) {
      const more = document.createElement('div');
      more.style.cssText = 'padding:0.5rem;color:var(--color-text-muted);font-size:0.75rem;text-align:center;';
      more.textContent = 'Showing first 50 results. Refine your search for more.';
      results.appendChild(more);
    }
  }

  // --- Mobile Sidebar Toggle ---
  $('#sidebar-toggle').addEventListener('click', () => {
    $('#sidebar').classList.toggle('open');
    $('#backdrop').classList.toggle('show');
  });

  // Create backdrop element
  const backdrop = document.createElement('div');
  backdrop.id = 'backdrop';
  document.body.appendChild(backdrop);
  backdrop.addEventListener('click', () => {
    $('#sidebar').classList.remove('open');
    $('#backdrop').classList.remove('show');
  });

  // --- Utilities ---
  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  function truncate(text, max) {
    return text.length > max ? text.substring(0, max) + '...' : text;
  }

  function copyToClipboard(text) {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).catch(() => {});
    }
  }

})();
